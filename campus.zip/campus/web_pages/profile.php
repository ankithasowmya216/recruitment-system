
<?php   //connection code
   session_start();
   error_reporting(0);
   require '../db/dbcon.php';
   require 'navbar.php';
   if(!isset($_SESSION['fname'])&&(!isset($_SESSION['sid'])))
  {
    header('location:login.php');
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>MY PROFILE</title>  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <script type="text/javascript" src="../js/jquery-3.3.1.slim.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../js/popper.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/profile.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@1,500&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Bitter&display=swap" rel="stylesheet">
</head>

<body>
    <br>
    <h1>Complete your profile for further process</h1><br>
    <button type="button" class="btn btn-light" style="float:right;text-decoration:none;"><a href="resume.php">View profile</a></button>
      
    <div class="container" ><br><br><!--div for whole form-->
         <h2>Personal Details</h2><br>
         <form action="profile.php" method="post" autocomplete="on" enctype="multipart/form-data">

            <div class="form-row"><!--first row-->
               <div class="col">
                   <label>Profile Picture</label><br><!--profile pic-->
                   <input type="file" class="form-control" id="ppic" placeholder="" name="ppic">
                </div>
             </div>
             <?php
               $filename=$_FILES["ppic"]["name"];
               $tempname=$_FILES["ppic"]["tmp_name"];
               $folder="../profilepic/".$filename;
               move_uploaded_file($tempname,$folder);
             ?>
          
            <div class="form-row"><!--first row-->
               <div class="col">
                   <label>Student ID</label><br><!--student id-->
                   <input type="text" class="form-control" id="stdid" placeholder="Student ID" name="sid" readonly value="<?php echo $_SESSION['sid'];?>">
                </div>
             </div><!--first row ends-->
             <div class="form-row"><!--second row-->
               <div class="col">
                   <label>First name</label><br><!--fname-->
                   <input type="text" class="form-control" id="fisrtname" placeholder="First Name" name="fname" readonly value="<?php echo $_SESSION['fname'];?>">
                </div>
                <div class="col">
                    <label >Last Name</label><br><!--lname-->
                   <input type="text" class="form-control" id="lastname" placeholder="Last name" name="lname" readonly value="<?php echo $_SESSION['lname'];?> ">
                </div>
             </div><!--second ror ends here-->
             <div class="form-row"><!--third row-->
               <div class="col">
                   <label>Email</label><br><!--email-->
                   <input type="email" class="form-control" id="email" placeholder="Email" name="email" readonly value="<?php echo $_SESSION['email'];?> ">
                </div>
                <div class="col">
                    <label >Gender</label><br><!--gender-->
                    <select class="form-control" id="gender" name="gender">
                        <option> </option>
                        <option>Male</option>
                        <option>Female</option>
                    </select>
                </div>
             </div><!--third row ends here-->
             <div class="form-row"><!--fourth  row-->
               <div class="col">
                   <label>Date of birth</label><br><!--dob-->
                   <input type="date" class="form-control" id="dob" placeholder="DOB" name="dob" required>
                </div>
                <div class="col">
                    <label >Phone</label><br><!--phone-->
                    <input type="number" class="form-control" id="phone" placeholder="Phone" name="phone" required>
                </div>
             </div><!--fourth row ends here-->
              <div class="form-row"><!--fifth row-->
               <div class="col">
                   <label>Location</label><br><!--location-->
                   <input type="text" class="form-control" id="loc" placeholder="Location" name="loc" required>
                </div>
              </div><!--fifth row ends here-->
              <br><br><h2>Educational qualification</h2><br>
              <h4>Graudation</h4><br>
                <div class="row"><!--6th row-->
                    <div class="col">
                        <label>College Name</label><br><!--clg name-->
                       <input type="text" class="form-control" id="cname" placeholder="College Name" name="deg_name" required>
                    </div>
                </div><!--6th row end-->
                <div class="row"><!--7th row-->
                    <div class="col">
                        <label>Stream</label><br><!--stream-->
                        <select class="form-control" id="stream" name="deg_stream">
                           <option> </option>
                           <option>Computer Science Engineering</option>
                           <option>Information Science Engineering</option>
                           <option>Electronics and Communications Engineering </option>
                           <option>Electrical and Electronics Engineering</option>
                           <option>Telecommunication Engineering</option>
                           <option>Mechanical Engineering</option>
                        </select>
                    </div>
                </div><!--7th row end-->
                <div class="row"><!--8th row-->
                    <div class="col">
                        <label>Percentage %</label><br><!--deg per-->
                       <input type="text" class="form-control" id="dper" placeholder="Percentage"  required name="deg_per">
                    </div>
                </div><!--8th row end-->
                <div class="row"><!--9th row-->
                    <div class="col">
                        <label>Backlogs</label><br><!--backlogs-->
                       <input type="number" class="form-control" id="dbacks" placeholder="Backlogs"  required name="deg_backs" min="0" max="10">
                    </div>
                </div><!--9th row end-->
               <br><br><h4>PU</h4><br>
                <div class="row"><!--first row-->
                    <div class="col">
                        <label>College Name</label><br><!-- pu clg name-->
                       <input type="text" class="form-control" id="cname" placeholder="College Name" required name="pu_name">
                    </div>
                </div>
                <div class="row"><!--second row-->
                    <div class="col">
                        <label>Percentage %</label><br><!--pu per-->
                       <input type="text" class="form-control" id="pper" placeholder="Percentage" name="pu_per" required>
                    </div>
                </div>
                <br><br><h4>School</h4><br>
                <div class="row"><!--first row-->
                    <div class="col">
                        <label>School Name</label><br><!--scl name-->
                       <input type="text" class="form-control" id="sname" placeholder="School Name" name="scl_name" required>
                    </div>
                </div>
                <div class="row"><!--second row-->
                    <div class="col">
                        <label>Percentage %</label><br><!--scl per-->
                       <input type="text" class="form-control" id="sper" placeholder="Percentage" name="scl_per" required>
                    </div>
                </div>
               <br><br><br>
                <center><button type="submit" class="btn btn-primary"  role="button" name="complete">Submit</button></center> 
            </form>
            <br><br>
          </div><!--div for whole form ends here-->
        <br><br><br>
    </body>
</html>
<?php

     if(isset($_POST['complete']))
     {
         $gender=$_POST['gender'];
         $dob=$_POST['dob'];
         $phone=$_POST['phone'];
         $location=$_POST['loc'];
         $deg_clg=$_POST['deg_name']; 
         $deg_stream=$_POST['deg_stream'];
         $deg_per=$_POST['deg_per'];
         $deg_backs=$_POST['deg_backs'];
         $pu_clg=$_POST['pu_name'];
         $pu_per=$_POST['pu_per'];
         $sch_name=$_POST['scl_name'];
         $sch_per=$_POST['scl_per'];
         $sid=$_SESSION['sid'];
         $f=1;
         
         $query="update student set  profile_pic='$folder',gender='$gender',dob='$dob',phone='$phone', location='$location',degree_clg='$deg_clg',degree_stream='$deg_stream',degree_per='$deg_per',degree_backlogs='$deg_backs',
         pu_clg='$pu_clg',pu_per='$pu_per',school_name='$sch_name',school_per='$sch_per',flag='$f' where sid='$sid'";
         /*$query= "update into student set (gender,dob,phone,location,degree_clg,degree_stream,degree_per,degree_backlogs,pu_clg,pu_per,school_name,school_per) values ($gender','$dob','$phone','$location','$deg_clg','$deg_stream','$deg_per','$deg_backs','$pu_clg','$pu_per','$sch_name','$sch_per')" ;*/

         $runquery=mysqli_query($con,$query);

         if($runquery)
            {
                echo '<script type="text/javascript">alert("Profile Completed") </script>';
               
            }
            else
            {
                echo '<script type="text/javascript"> alert("Please complete your profile") </script>';
            }
        }
    ?>






