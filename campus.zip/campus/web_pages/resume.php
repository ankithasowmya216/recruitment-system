<?php   //connection code
   session_start();
   
   require '../db/dbcon.php';
   if(!isset($_SESSION['fname'])&&(!isset($_SESSION['sid'])))
  {
    header('location:login.php');
  }
?>
<?php // code for fixed navbar
   require 'navbar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>PROFILE</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <script type="text/javascript" src="../js/jquery-3.3.1.slim.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../js/popper.min.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@1,500&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Bitter&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="../css/resume.css">
    <style>
    .form-group{
      width:400px;
      margin-top:20px;
      margin-left:230px;
    }
    </style>
</head>
<body><br>
    <h1>Welcome <?php echo $_SESSION['fname'];?></h1>
      <a href="update.php" style="float:right">Update</a>
    <?php
    $sid=$_SESSION['sid'];
    $query="select * from student where sid='$sid'";
    $runquery = mysqli_query($con,$query);
    if(mysqli_num_rows($runquery)>0)
    {
      $temp_array = mysqli_fetch_assoc($runquery);
      $sid=$temp_array['sid'];
      $fname=$temp_array['fname'];
      $lname=$temp_array['lname'];
      $email=$temp_array['email'];
      $gender=$temp_array['gender'];
      $dob=$temp_array['dob'];
      $phone=$temp_array['phone'];
      $location=$temp_array['location'];
      $deg_name=$temp_array['degree_clg'];
      $deg_stream=$temp_array['degree_stream'];
      $deg_per=$temp_array['degree_per'];
      $deg_back=$temp_array['degree_backlogs'];
      $pu_name=$temp_array['pu_clg'];
      $pu_per=$temp_array['pu_per'];
      $s_name=$temp_array['school_name'];
      $s_per=$temp_array['school_per'];
      $img=$temp_array['profile_pic'];
      

      $_SESSION['sid']=$sid;
      $_SESSION['fname']=$fname;
      $_SESSION['lname']=$lname;
      $_SESSION['email']=$email;
      $_SESSION['gender']=$gender;
      $_SESSION['dob']=$dob;
      $_SESSION['phone']=$phone;
      $_SESSION['location']=$location;
      $_SESSION['degree_name']=$deg_name;
      $_SESSION['degree_stream']=$deg_stream;
      $_SESSION['degree_per']=$deg_per;
      $_SESSION['degree_backlogs']=$deg_back;
      $_SESSION['pu_name']=$pu_name;
      $_SESSION['pu_per']=$pu_per;
      $_SESSION['school_name']=$s_name;
      $_SESSION['school_per']=$s_per;
      $_SESSION['pic']=$img;

    }
    ?>
    
  <form>
  <div class="form-group1"><!--sid-->
    
    <img src="<?php echo $_SESSION['pic']?>" alt="rc" height="100px" width="200px">
  </div>
  <div class="container1" >
  <div class="form-group" id="personal"><!--sid-->
    <label><b>Student ID</b></label><br>
    <input type="text" class="form-control" id="personal" readonly value="<?php echo $_SESSION['sid'];?>">
  </div>
  <div class="form-group"id="personal"><!--fname-->
    <label><b>First Name</b></label><br>
    <input type="text" class="form-control"id="personal" readonly value="<?php echo $_SESSION['fname'];?>">
  </div>
  <div class="form-group"id="personal"><!--lname-->
    <label><b>Last Name</b></label><br>
    <input type="text" class="form-control" id="personal"readonly value="<?php echo $_SESSION['lname'];?>">
  </div>
  <div class="form-group"id="personal"><!--email-->
    <label><b>Email ID</b></label><br>
    <input type="text" class="form-control"id="personal" readonly value="<?php echo $_SESSION['email'];?>">
  </div>
  <div class="form-group"id="personal"><!--gender-->
    <label><b>Gender</b></label><br>
    <input type="text" class="form-control"id="personal" readonly value="<?php echo $_SESSION['gender'];?>">
  </div>
  <div class="form-group"id="personal"><!--dob-->
    <label><b>Date of Birth</b></label><br>
    <input type="text" class="form-control"id="personal" readonly value="<?php echo $_SESSION['dob'];?>">
  </div>
  <div class="form-group"id="personal"><!--phone-->
    <label><b>Phone</b></label><br>
    <input type="text" class="form-control" id="personal"readonly value="<?php echo $_SESSION['phone'];?>">
  </div>
  </div>
  <h3>Educational qualifications</h3><br>
  <div class="container2" >
  <h2>Graduation</h2><br>
  <div class="form-group"><!--deg_name-->
    <label><b>College Name</b></label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['degree_name'];?>">
  </div>
  <div class="form-group"><!--deg_stream-->
    <label><b>Stream</b></label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['degree_stream'];?>">
  </div>
  <div class="form-group"><!--deg_per-->
    <label><b>Percentage</b></label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['degree_per'];?>">
  </div>
  <div class="form-group"><!--deg_backs-->
    <label><b>Backlogs</b></label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['degree_backlogs'];?>">
  </div>
  </div>
  <br>
  <div class="container3" >
  <h2>PU</h2><br>
  <div class="form-group"><!--pu_name-->
    <label><b>College Name</b></label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['pu_name'];?>">
  </div>
  <div class="form-group"><!--pu_per-->
    <label><b>Percentage</b></label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['pu_per'];?>">
  </div>
  </div>
  <br>
  <div class="container4" >
  <h2>School</h2><br>
  <div class="form-group"><!--school_name-->
    <label><b>School Name</b></label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['school_name'];?>">
  </div>
  <div class="form-group"><!--school_per-->
    <label><b>Percentage</b></label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['school_per'];?>">
  </div>
  </div>

  
</form>
</body>
</html>