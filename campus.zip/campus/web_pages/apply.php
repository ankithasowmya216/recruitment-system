
<?php /*db connection*/
session_start();
require '../db/dbcon.php';

if(!isset($_SESSION['fname'])&&(!isset($_SESSION['sid'])))
{
 header('location:login.php');
}
$usn=$_SESSION['sid'];
$my_10=$_SESSION['school_per'];
$my_12=$_SESSION['pu_per'];
$my_deg=$_SESSION['degree_per'];
$my_backs=$_SESSION['degree_backlogs'];
if(isset($_POST['apply']))
{
    $cid=$_POST['app'];
    $query= "select * from applied where sid='$usn' and cid='$cid'";
    $runquery = mysqli_query($con, $query);

    
    if(mysqli_num_rows($runquery)>0)
    {
        echo '<script type="text/javascript"> alert(" you have already Registered, try another!") </script>';
    }
    else
    {
    $cid=$_POST['app'];
    $query="select * from company where cid=$cid";
    $runquery = mysqli_query($con,$query);
    $data= mysqli_fetch_assoc($runquery);
    $p_10=$data['cut_10'];
    $p_12=$data['cut_12'];
    $p_deg=$data['cut_deg'];
    $b_deg=$data['deg_backlogs'];
    
    if(($my_10>=$p_10)&&($my_12>=$p_12)&&($my_deg>=$p_deg)&&($my_backs<=$b_deg))
    {

        $query="insert into applied (cid,sid) values ('$cid','$usn')";
        $runquery = mysqli_query($con,$query);
        if($runquery)
        {
           echo '<script type="text/javascript">alert("Application has been submitted successfully") </script>';
           header('location:resume.php');
        }
        else
        {
          echo '<script type="text/javascript">alert("Error") </script>';
        }
    }
    else
    {
        
        echo '<script type="text/javascript">alert("Not Eligible") </script>';
       
    }
}
}
else
{ 
     echo "failure";
}
    
?>