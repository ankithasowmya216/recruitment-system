<?php   //connection code
   session_start();
   
   error_reporting(0);
   require '../db/dbcon.php';
   require 'navbar.php';
   if(!isset($_SESSION['fname'])&&(!isset($_SESSION['sid'])))
  {
    header('location:login.php');
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>UPDATE</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <script type="text/javascript" src="../js/jquery-3.3.1.slim.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../js/popper.min.js"></script>
    
    
<link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@1,500&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Bitter&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="../css/update.css">
</head>
<body>
    <?php
    $sid=$_SESSION['sid'];
    $query="select * from student where sid='$sid'";
    $runquery = mysqli_query($con,$query);
    if(mysqli_num_rows($runquery)>0)
    {
      $temp_array = mysqli_fetch_assoc($runquery);
      $sid=$temp_array['sid'];
      $fname=$temp_array['fname'];
      $lname=$temp_array['lname'];
      $email=$temp_array['email'];
      $gender=$temp_array['gender'];
      $dob=$temp_array['dob'];
      $phone=$temp_array['phone'];
      $location=$temp_array['location'];
      $deg_name=$temp_array['degree_clg'];
      $deg_stream=$temp_array['degree_stream'];
      $deg_per=$temp_array['degree_per'];
      $deg_back=$temp_array['degree_backlogs'];
      $pu_name=$temp_array['pu_clg'];
      $pu_per=$temp_array['pu_per'];
      $s_name=$temp_array['school_name'];
      $s_per=$temp_array['school_per'];
      $img=$temp_array['profile_pic'];
      

      $_SESSION['sid']=$sid;
      $_SESSION['fname']=$fname;
      $_SESSION['lname']=$lname;
      $_SESSION['email']=$email;
      $_SESSION['gender']=$gender;
      $_SESSION['dob']=$dob;
      $_SESSION['phone']=$phone;
      $_SESSION['location']=$location;
      $_SESSION['degree_name']=$deg_name;
      $_SESSION['degree_stream']=$deg_stream;
      $_SESSION['degree_per']=$deg_per;
      $_SESSION['degree_backlogs']=$deg_back;
      $_SESSION['pu_name']=$pu_name;
      $_SESSION['pu_per']=$pu_per;
      $_SESSION['school_name']=$s_name;
      $_SESSION['school_per']=$s_per;
      $_SESSION['pic']=$img;
    }
    ?>
    <div class="container" >
    <form method="post"  enctype="multipart/form-data">
    <div class="form-row"><!--first row-->
               <div class="col">
                   <label>Profile Picture</label><br><!--profile pic-->
                   <input type="file" class="form-control" id="ppic" placeholder="" name="ppic">
                </div>
             </div>
             <?php
               $filename=$_FILES["ppic"]["name"];
               $tempname=$_FILES["ppic"]["tmp_name"];
               $folder="../profilepic/".$filename;
               move_uploaded_file($tempname,$folder);
             ?>
          
  
  <div class="form-group"><!--sid-->
    <label>Student ID</label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['sid'];?>">
  </div>
  <div class="form-row">
  <div class="col"><!--fname-->
    <label>First Name</label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['fname'];?>">
  </div>
  <div class="col"><!--lname-->
  <label>Last Name</label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['lname'];?>">
  </div>
</div>

<div class="form-row">
<div class="col"><!--email-->
<label>Email ID</label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['email'];?>">
</div>
<div class="col">
<label>Date of Birth</label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['dob'];?>">
</div>
</div>
  
<div class="form-group"><!--phone-->
    <label>Phone</label><br>
    <input type="number" class="form-control"  name="phone" value=" ">
</div>

  <h3>Educational qualifications</h3><br>
  <h2>Graudation</h2><br>

  <div class="form-row">
  <div class="col">
  <label>College Name</label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['degree_name'];?>">
  </div>
  <div class="col">
  <label>Stream</label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['degree_stream'];?>">
  </div>
  </div>
  <div class="form-row">
  <div class="col">
  <label>Percentage</label><br>
    <input type="text" class="form-control" name="deg_per" value=" ">
  </div>
  <div class="col">
  <label>Backlogs</label><br>
    <input type="number" class="form-control"  name="deg_backs" value=" ">
  </div>
  </div>
  <br>
  <h2>PU</h2>
  <div class="form-row">
  <div class="col">
  <label>College Name</label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['pu_name'];?>">
  </div>
  <div class="col">
  <label>Percentage</label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['pu_per'];?>">
  </div>
  </div>
  
  <br>
  <h2>School</h2><br>
  <div class="form-row">
  <div class="col">
  <label>School Name</label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['school_name'];?>">
  </div>
  <div class="col">
  <label>Percentage</label><br>
    <input type="text" class="form-control" readonly value="<?php echo $_SESSION['school_per'];?>">
  </div>
  </div>
   </div><br><br>
  <center><button type="submit" class="btn btn-primary"  role="button" name="update">Update </button></center> 
</form>
  </div>
</div>
</body>
</html>
<?php
if(isset($_POST['update']))
{
  $phone=$_POST['phone'];
  $deg_per=$_POST['deg_per'];
  $deg_backs=$_POST['deg_backs'];
  $sid=$_SESSION['sid'];

  $query="update student set profile_pic='$folder',phone='$phone',degree_per='$deg_per',degree_backlogs='$deg_backs' where sid='$sid'";

  $runquery=mysqli_query($con,$query);

  if($runquery){
    echo '<script type="text/javascript">alert("Profile Updated") </script>';
    
  }
}
else{
  
}
?>
