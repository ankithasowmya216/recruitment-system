<?php 
   require '../db/dbcon.php';
   session_start();
   error_reporting(0);
   //require 'PHPMailer/PHPMailerAutoload.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sign up</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <script type="text/javascript" src="../js/jquery-3.3.1.slim.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../js/popper.min.js"></script>
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../css/register.css">
   
</head>

<body>
    <div class="container-fluid-lg bg">
            <div class="myform">
                <h2>Sign up Here</h2><br>
                <form action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>" method="post" autocomplete="off" enctype="multipart/form-data">
                   
                    <div class="row">
                        <div class="form-group col-6">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
</svg>
                            <label for="f1"> First Name</label><br>
                            <input type="text" id="f1" name="fname" required>
                        </div>
                        <div class="form-group col-6">
                            <label for="f2">Last Name</label><br>
                            <input type="text" id="f2" name="lname" required>
                        </div>
                    </div> <!--first row-->
                    <div class="row">
                        <div class="form-group col-6">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-check-fill" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M1 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm9.854-2.854a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 0 1 .708-.708L12.5 7.793l2.646-2.647a.5.5 0 0 1 .708 0z"/>
</svg>
                            <label for="f3">Student ID</label><br>
                            <input type="text" id="f3" name="sid"  required>
                        </div>
                        <div class="form-group col-6">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope-fill" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414.05 3.555zM0 4.697v7.104l5.803-3.558L0 4.697zM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586l-1.239-.757zm3.436-.586L16 11.801V4.697l-5.803 3.546z"/>
</svg>
                            <label for="f4">Email</label><br>
                            <input type="email" id="f4" name="email" required>
                        </div>
                    </div> <!--second row-->
                    <div class="row">
                        <div class="form-group col-6">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-lock2-fill" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M12 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zM7 6a1 1 0 0 1 2 0v1H7V6zm3 0v1.076c.54.166 1 .597 1 1.224v2.4c0 .816-.781 1.3-1.5 1.3h-3c-.719 0-1.5-.484-1.5-1.3V8.3c0-.627.46-1.058 1-1.224V6a2 2 0 1 1 4 0z"/>
</svg>
                            <label for="f5">Password</label><br>
                            <input type="password" id="f5" name="pass" required>
                        </div>
                        <div class="form-group col-6">
                            <label for="f6">Confirm Password</label><br>
                            <input type="password" id="f6" name="cpass" required>
                            <br><br>
                        </div>
                    </div> <!--third row-->
                    <div class="row justify-content-center">
                        <button type="submit" name="register" class="btn btn-effects" >Sign Up</button>
                    </div><br>
                   <b><center><a href="login.php">Back to Login</a></center></b><br>
                </form>
            </div>
        </div>
    
</body>
</html>

<?php
    if (isset($_POST['register'])) 
    {
        $fname=$_POST['fname'];
        $lname=$_POST['lname'];
        $sid=$_POST['sid'];
        $email=$_POST['email'];
        $pass=$_POST['pass'];
        $cpass=$_POST['cpass'];

        if($pass==$cpass)
        {
            $query= "select * from student where sid='$sid'";
            $runquery = mysqli_query($con, $query);
            
            if(mysqli_num_rows($runquery)>0)
            {
                echo '<script type="text/javascript"> alert("Already registered with the same Student ID!!") </script>';
            }
            else
            {
                $query= "insert into student (sid,fname,lname,email,pwd,gender,dob,phone,location,degree_clg,degree_stream,degree_per,degree_backlogs,pu_clg,pu_per,school_name,school_per,flag) values ('$sid','$fname','$lname','$email','$pass','','','','','','','','','','','','','0')";
                $runquery = mysqli_query($con,$query);
                if($runquery)
                {
                    
                    echo '<script type="text/javascript">alert("Registration successful")</script>';
                
            
                }
                else
                {
                    echo '<script type="text/javascript"> alert("Unable to register") </script>';
                }
            }
        }
        else
        {
            echo '<script type="text/javascript"> alert("Passwords do not match.Password and Confirm password must be same") </script>';
        }
    }
?>