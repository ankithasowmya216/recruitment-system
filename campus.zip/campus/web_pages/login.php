<?php 
   session_start();
   error_reporting(0);
   require '../db/dbcon.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>LOGIN</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <script type="text/javascript" src="../js/jquery-3.3.1.slim.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../js/popper.min.js"></script>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../css/login.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
</head>
<body>

    <div class="container-fluid-lg bg">
            <div class="outerbox">

               <div class="center">
                   <h1>LOGIN</h1>
                   <div class=" container loginbox">
                   <form action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>" method="post" autocomplete="off">

                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
</svg>
        
                <label>Student ID</label>
                    <br>
                    <input type="text" placeholder="Student ID" id="sfield" name="stdid" >
                    <br><br>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-key-fill" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M3.5 11.5a3.5 3.5 0 1 1 3.163-5H14L15.5 8 14 9.5l-1-1-1 1-1-1-1 1-1-1-1 1H6.663a3.5 3.5 0 0 1-3.163 2zM2.5 9a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
</svg>
                    <label>Password</label> <br>
                    <input type="password" placeholder="Password" id="pfiles" name="pass">
                    <br><br><br>
                    <div class="row justify-content-center">
                        <button type="submit"  class="btn btn-effects" name="login" >Login</button>
                    </div><br>
                    <h6>Don't have an account?
                        <a href="register.php" style="font-size: larger;">Sign up here</a></h6>
                </form>
                <?php
                    if(isset($_POST['login']))
                    {
                        $sid=$_POST['stdid'];
                        $pass=$_POST['pass'];
                        $query = " select * from student where sid='$sid' and pwd='$pass'";
                        $runquery = mysqli_query($con,$query);
                        if(mysqli_num_rows($runquery)>0)
                        {
                        $sid_temp = mysqli_fetch_assoc($runquery);
                        $db_name = $sid_temp['fname'];
                        $db_id=$sid_temp['sid'];
                        $db_lname=$sid_temp['lname'];
                        $db_email=$sid_temp['email'];
                        $flag=$sid_temp['flag'];
                       
                        $_SESSION['fname']= $db_name;
                        $_SESSION['sid']=$db_id;
                        $_SESSION['lname']=$db_lname;
                        $_SESSION['email']=$db_email;
                       
                       echo '<script type="text/javascript"> alert("Login Successful") </script>';
                        if($flag==0)
                        {  
                           header('location:profile.php');
                        }
                        else
                        {
                            header('location:resume.php');
                        }
                        
                        }
                        else
                        {
                        echo '<script type="text/javascript"> alert("Ivalid Student Id or Password") </script>';
                        }
                    }
                ?>
                </div>
            </div>
        </div>
    
</body>
</html>